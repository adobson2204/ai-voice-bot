import { useState, useEffect } from 'react';

export default function SetupStatus({ setupStatus, checkEnvironmentSetup, isLoading }) {
  const [showDetails, setShowDetails] = useState(false);

  // Auto-check setup status on component mount
  useEffect(() => {
    if (!setupStatus) {
      checkEnvironmentSetup();
    }
  }, []);

  if (!setupStatus) {
    return (
      <div className="bg-gray-50 rounded-lg p-4 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
            <span className="text-sm text-gray-600">Checking Twilio setup...</span>
          </div>
        </div>
      </div>
    );
  }

  const statusColor = setupStatus.success ? 'green' : 'red';
  const statusIcon = setupStatus.success ? '✅' : '❌';

  return (
    <div className={`rounded-lg p-4 mb-6 border-l-4 ${setupStatus.success ? 'bg-green-50 border-green-400' : 'bg-red-50 border-red-400'}`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="text-lg">{statusIcon}</span>
          <div>
            <h3 className={`font-medium ${setupStatus.success ? 'text-green-800' : 'text-red-800'}`}>
              Twilio Integration {setupStatus.success ? 'Ready' : 'Setup Required'}
            </h3>
            <p className={`text-sm ${setupStatus.success ? 'text-green-600' : 'text-red-600'}`}>
              {setupStatus.message}
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowDetails(!showDetails)}
            className="text-sm text-blue-600 hover:text-blue-800 font-medium"
          >
            {showDetails ? 'Hide Details' : 'Show Details'}
          </button>
          <button
            onClick={checkEnvironmentSetup}
            disabled={isLoading}
            className="px-3 py-1 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? 'Checking...' : 'Refresh'}
          </button>
        </div>
      </div>

      {showDetails && (
        <div className="mt-4 space-y-3">
          <div className="bg-white rounded-lg p-3 border">
            <h4 className="font-medium text-gray-800 mb-2">Environment Variables Status:</h4>
            <div className="space-y-2 text-sm">
              {Object.entries(setupStatus.variables).map(([key, value]) => (
                <div key={key} className="flex justify-between items-center">
                  <span className="font-mono text-gray-600">{key}:</span>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    value.includes('NOT SET') 
                      ? 'bg-red-100 text-red-800' 
                      : 'bg-green-100 text-green-800'
                  }`}>
                    {value}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {setupStatus.recommendations && setupStatus.recommendations.length > 0 && (
            <div className="bg-yellow-50 rounded-lg p-3 border border-yellow-200">
              <h4 className="font-medium text-yellow-800 mb-2">Recommendations:</h4>
              <ul className="space-y-1 text-sm text-yellow-700">
                {setupStatus.recommendations.map((rec, index) => (
                  <li key={index} className="flex items-start space-x-1">
                    <span>•</span>
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {setupStatus.success && (
            <div className="bg-green-50 rounded-lg p-3 border border-green-200">
              <h4 className="font-medium text-green-800 mb-2">Next Steps:</h4>
              <ul className="space-y-1 text-sm text-green-700">
                <li className="flex items-start space-x-1">
                  <span>•</span>
                  <span>Try the "Test Call Me" feature to verify your setup</span>
                </li>
                <li className="flex items-start space-x-1">
                  <span>•</span>
                  <span>Create a campaign and start making outbound calls</span>
                </li>
                <li className="flex items-start space-x-1">
                  <span>•</span>
                  <span>Monitor your call results and appointments</span>
                </li>
              </ul>
            </div>
          )}

          <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
            <h4 className="font-medium text-blue-800 mb-2">Your Twilio Credentials:</h4>
            <div className="space-y-1 text-sm text-blue-700 font-mono">
              <div>Account SID: AC9dda637290c5c45941b81545482ca062f</div>
              <div>Phone Number: +12313998852</div>
              <div>Auth Token: ••••••••••••••••••••••••••••••••</div>
            </div>
            <p className="mt-2 text-xs text-blue-600">
              These should match your Saved Secrets configuration exactly
            </p>
          </div>
        </div>
      )}
    </div>
  );
}