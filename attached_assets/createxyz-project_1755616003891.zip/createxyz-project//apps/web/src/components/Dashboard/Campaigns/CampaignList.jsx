import {
  Play,
  Pause,
  Plus,
  Trash2,
  PhoneCall,
  TestTube,
} from "lucide-react";

function CampaignItem({ campaign, onToggle, onDelete }) {
  return (
    <div
      className="flex flex-col sm:flex-row sm:items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors gap-4"
    >
      <div className="flex items-center gap-4">
        <div
          className={`w-3 h-3 rounded-full flex-shrink-0 ${
            campaign.isRunning ? "bg-green-500" : "bg-gray-400"
          }`}
        ></div>
        <div className="min-w-0">
          <div className="font-semibold text-[#101828] text-sm lg:text-base">
            {campaign.name}
          </div>
          <div className="text-xs lg:text-sm text-[#667085] break-words">
            State: {campaign.state} • {campaign.callsMade} calls
            made • {campaign.appointmentsBooked} appointments
          </div>
        </div>
      </div>
      <div className="flex items-center gap-2 justify-end">
        <button
          onClick={() => onToggle(campaign.id)}
          className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors min-w-[80px] justify-center ${
            campaign.isRunning
              ? "bg-red-100 text-red-700 hover:bg-red-200"
              : "bg-green-100 text-green-700 hover:bg-green-200"
          }`}
        >
          {campaign.isRunning ? (
            <Pause size={14} />
          ) : (
            <Play size={14} />
          )}
          {campaign.isRunning ? "Pause" : "Start"}
        </button>
        <button
          onClick={() => onDelete(campaign.id)}
          className="w-8 h-8 flex items-center justify-center text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors"
        >
          <Trash2 size={16} />
        </button>
      </div>
    </div>
  );
}

export default function CampaignList({
  campaigns,
  onToggle,
  onDelete,
  onShowNewCampaignModal,
  onShowCallNumbersModal,
  onShowTestCallModal,
}) {
  return (
    <div
      id="campaigns"
      className="bg-white rounded-xl border border-[#EAECF0] mb-6 lg:mb-8"
    >
      <div className="p-4 lg:p-6 border-b border-[#EAECF0]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <h3 className="text-lg font-semibold text-[#101828]">
            Campaigns
          </h3>
          <div className="flex gap-2 flex-wrap">
            <button
              onClick={onShowTestCallModal}
              className="flex items-center justify-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-sm lg:text-base"
            >
              <TestTube size={16} />
              Test Call Me
            </button>
            <button
              onClick={onShowCallNumbersModal}
              className="flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm lg:text-base"
            >
              <PhoneCall size={16} />
              Call Numbers
            </button>
            <button
              onClick={onShowNewCampaignModal}
              className="flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm lg:text-base"
            >
              <Plus size={16} />
              New Campaign
            </button>
          </div>
        </div>
      </div>

      <div className="p-4 lg:p-6">
        {campaigns.length === 0 ? (
          <div className="text-center py-8 text-gray-500 text-sm lg:text-base">
            No campaigns yet. Create your first campaign to get started.
          </div>
        ) : (
          <div className="space-y-4">
            {campaigns.map((campaign) => (
              <CampaignItem
                key={campaign.id}
                campaign={campaign}
                onToggle={onToggle}
                onDelete={onDelete}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
