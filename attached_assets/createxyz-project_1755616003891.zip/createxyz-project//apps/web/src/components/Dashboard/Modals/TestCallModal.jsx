import { useState } from "react";
import { X, TestTube, AlertCircle, Phone } from "lucide-react";

export default function TestCallModal({
  show,
  onClose,
  onTest,
  campaigns,
  isLoading,
}) {
  const [testData, setTestData] = useState({
    campaignId: "",
    phoneNumber: "",
    customScript: "",
  });
  const [demoMode, setDemoMode] = useState(false);

  const handleTest = () => {
    onTest({ ...testData, demoMode });
  };

  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="w-full max-w-md bg-white rounded-xl shadow-xl border border-[#EAECF0] max-h-[90vh] overflow-y-auto">
        <div className="p-4 lg:p-6 border-b border-[#EAECF0]">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-[#101828]">
              {demoMode ? "Demo Call Test" : "Real AI Call Test"}
            </h3>
            <button
              onClick={onClose}
              className="w-8 h-8 flex items-center justify-center text-[#D0D5DD] hover:text-[#667085] transition-colors"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        <div className="p-4 lg:p-6 space-y-4">
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <label className="flex items-center space-x-3 cursor-pointer">
              <input
                type="checkbox"
                checked={demoMode}
                onChange={(e) => setDemoMode(e.target.checked)}
                className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                disabled={isLoading}
              />
              <div className="flex items-center space-x-2">
                <TestTube size={16} className="text-blue-600" />
                <span className="text-sm font-medium text-blue-900">
                  Demo Mode
                </span>
              </div>
            </label>
            <p className="text-xs text-blue-700 mt-1 ml-7">
              {demoMode
                ? "Simulate a call test without making an actual phone call. Perfect for testing without Twilio setup!"
                : "Make a real phone call to test Agent Brian. Requires Twilio credentials."}
            </p>
          </div>

          {!demoMode && (
            <>
              <div className="bg-green-50 border border-green-200 rounded-lg p-3 text-sm text-green-800">
                <strong>📞 Real Call Test:</strong> This will make an actual
                phone call to your number using our AI bot. Make sure you're
                ready to answer!
              </div>

              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-800">
                <div className="flex items-start gap-2">
                  <AlertCircle size={16} className="mt-0.5 flex-shrink-0" />
                  <div>
                    <strong>Setup Required:</strong> You need Twilio credentials
                    configured:
                    <ul className="mt-1 list-disc list-inside space-y-1 text-xs">
                      <li>TWILIO_ACCOUNT_SID</li>
                      <li>TWILIO_AUTH_TOKEN</li>
                      <li>TWILIO_PHONE_NUMBER</li>
                    </ul>
                  </div>
                </div>
              </div>
            </>
          )}

          {demoMode && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-800">
              <strong>🎭 Demo Mode:</strong> Agent Brian will simulate a
              realistic test call scenario without making an actual phone call.
              This helps you understand the conversation flow and test your
              scripts.
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-[#101828] mb-2">
              Select Campaign to Test
            </label>
            <select
              value={testData.campaignId}
              onChange={(e) =>
                setTestData({ ...testData, campaignId: e.target.value })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-base"
              disabled={isLoading}
            >
              <option value="">Choose a campaign to test...</option>
              {campaigns.map((campaign) => (
                <option key={campaign.id} value={campaign.id}>
                  {campaign.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-[#101828] mb-2">
              {demoMode ? "Test Phone Number" : "Your Phone Number"}
            </label>
            <input
              type="tel"
              value={testData.phoneNumber}
              onChange={(e) =>
                setTestData({ ...testData, phoneNumber: e.target.value })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-base"
              placeholder={
                demoMode
                  ? "555-123-4567 (for demo purposes)"
                  : "+1234567890 (include country code)"
              }
              disabled={isLoading}
            />
            <div className="text-xs text-[#667085] mt-1">
              {demoMode
                ? "Any phone number format for demo purposes"
                : "Include country code (e.g., +1 for US numbers)"}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-[#101828] mb-2">
              Custom Test Script (Optional)
            </label>
            <div className="text-xs text-[#667085] mb-2">
              Leave blank to use the campaign's default script, or enter a
              custom script to test specific messaging.
            </div>
            <textarea
              value={testData.customScript}
              onChange={(e) =>
                setTestData({ ...testData, customScript: e.target.value })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 h-24 resize-none text-base"
              placeholder="Hello, I'm calling about our special life insurance offer..."
              disabled={isLoading}
            />
          </div>

          <div
            className={`border rounded-lg p-3 text-sm ${demoMode ? "bg-blue-50 border-blue-200 text-blue-800" : "bg-green-50 border-green-200 text-green-800"}`}
          >
            <strong>
              {demoMode ? "🎭 Demo Process:" : "📋 How it works:"}
            </strong>
            <ul className="mt-1 list-disc list-inside space-y-1">
              {demoMode ? (
                <>
                  <li>Agent Brian will simulate a realistic conversation</li>
                  <li>You'll see the simulated outcomes and responses</li>
                  <li>Test different scripts and campaign setups</li>
                  <li>No actual calls are made or charges incurred</li>
                  <li>Perfect for training and script optimization</li>
                </>
              ) : (
                <>
                  <li>The AI bot will call you within ~5 seconds</li>
                  <li>Answer and interact naturally with the bot</li>
                  <li>
                    Test different responses (interested, not interested,
                    questions)
                  </li>
                  <li>The call will be recorded for quality review</li>
                  <li>Try booking an appointment to test the full flow</li>
                </>
              )}
            </ul>
          </div>
        </div>

        <div className="p-4 lg:p-6 border-t border-[#EAECF0] flex flex-col sm:flex-row gap-3">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-base"
            disabled={isLoading}
          >
            Cancel
          </button>
          <button
            onClick={handleTest}
            className={`flex-1 px-4 py-3 text-white rounded-lg transition-colors text-base flex items-center justify-center gap-2 ${
              demoMode
                ? "bg-blue-600 hover:bg-blue-700"
                : "bg-purple-600 hover:bg-purple-700"
            }`}
            disabled={
              isLoading || !testData.campaignId || !testData.phoneNumber
            }
          >
            {isLoading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                {demoMode ? "Running Demo..." : "Initiating Call..."}
              </>
            ) : (
              <>
                {demoMode ? <TestTube size={16} /> : <Phone size={16} />}
                {demoMode ? "Start Demo Test" : "Start Real Call Test"}
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
