import { useState } from "react";
import { X, PhoneCall, TestTube } from "lucide-react";

export default function CallNumbersModal({
  show,
  onClose,
  onCall,
  campaigns,
  isLoading,
}) {
  const [campaignId, setCampaignId] = useState("");
  const [phoneNumbers, setPhoneNumbers] = useState("");
  const [demoMode, setDemoMode] = useState(false);

  const handleCall = () => {
    onCall({ campaignId, phoneNumbers, demoMode });
  };

  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="w-full max-w-md bg-white rounded-xl shadow-xl border border-[#EAECF0] max-h-[90vh] overflow-y-auto">
        <div className="p-4 lg:p-6 border-b border-[#EAECF0]">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-[#101828]">
              Call Specific Numbers
            </h3>
            <button
              onClick={onClose}
              className="w-8 h-8 flex items-center justify-center text-[#D0D5DD] hover:text-[#667085] transition-colors"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        <div className="p-4 lg:p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-[#101828] mb-2">
              Select Campaign
            </label>
            <select
              value={campaignId}
              onChange={(e) => setCampaignId(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-base"
              disabled={isLoading}
            >
              <option value="">Choose a campaign...</option>
              {campaigns.map((campaign) => (
                <option key={campaign.id} value={campaign.id}>
                  {campaign.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-[#101828] mb-2">
              Phone Numbers
            </label>
            <div className="text-xs text-[#667085] mb-2">
              Enter one phone number per line. Formats accepted: (555) 123-4567,
              555-123-4567, 5551234567
            </div>
            <textarea
              value={phoneNumbers}
              onChange={(e) => setPhoneNumbers(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 h-32 resize-none text-base font-mono"
              placeholder="555-123-4567
(555) 234-5678
5553456789"
              disabled={isLoading}
            />
          </div>

          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <label className="flex items-center space-x-3 cursor-pointer">
              <input
                type="checkbox"
                checked={demoMode}
                onChange={(e) => setDemoMode(e.target.checked)}
                className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                disabled={isLoading}
              />
              <div className="flex items-center space-x-2">
                <TestTube size={16} className="text-blue-600" />
                <span className="text-sm font-medium text-blue-900">
                  Demo Mode
                </span>
              </div>
            </label>
            <p className="text-xs text-blue-700 mt-1 ml-7">
              {demoMode
                ? "Agent Brian will simulate realistic call outcomes without making actual calls. Perfect for testing without Twilio setup!"
                : "Real calls will be made using Twilio. Requires valid Twilio credentials."}
            </p>
          </div>
        </div>

        <div className="p-4 lg:p-6 border-t border-[#EAECF0] flex flex-col sm:flex-row gap-3">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-base"
            disabled={isLoading}
          >
            Cancel
          </button>
          <button
            onClick={handleCall}
            className={`flex-1 px-4 py-3 text-white rounded-lg transition-colors text-base flex items-center justify-center gap-2 ${
              demoMode
                ? "bg-blue-600 hover:bg-blue-700"
                : "bg-green-600 hover:bg-green-700"
            }`}
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                {demoMode ? "Simulating..." : "Calling..."}
              </>
            ) : (
              <>
                {demoMode ? <TestTube size={16} /> : <PhoneCall size={16} />}
                {demoMode ? "Start Demo" : "Start Calling"}
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
