import { Menu } from "lucide-react";

export default function Header({ onToggleSidebar }) {
  return (
    <>
      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-40 flex items-center justify-between p-4 bg-white border-b border-gray-200 shadow-sm">
        <h1 className="text-lg font-semibold text-[#101828]">
          CallBot Manager
        </h1>
        <button
          onClick={onToggleSidebar}
          className="w-10 h-10 flex items-center justify-center text-gray-700 hover:bg-gray-100 rounded-lg border border-gray-300 transition-colors"
        >
          <Menu size={20} />
        </button>
      </div>

      {/* Desktop Header */}
      <div className="hidden lg:block fixed top-0 left-0 right-0 z-30 bg-white border-b border-gray-200">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-4">
            <button
              onClick={onToggleSidebar}
              className="w-10 h-10 flex items-center justify-center text-gray-600 hover:bg-gray-100 rounded-lg"
            >
              <Menu size={20} />
            </button>
            <h1 className="text-lg font-semibold text-[#101828]">
              CallBot Manager
            </h1>
          </div>
        </div>
      </div>
    </>
  );
}
