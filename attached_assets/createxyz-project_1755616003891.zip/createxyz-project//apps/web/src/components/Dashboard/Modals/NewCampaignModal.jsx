import { useState } from "react";
import { X, FileText } from "lucide-react";
import { LIFE_INSURANCE_SCRIPT_TEMPLATE } from "../Scripts/LifeInsuranceTemplate";

const states = [
  { value: "CA", name: "California" },
  { value: "TX", name: "Texas" },
  { value: "NY", name: "New York" },
  { value: "FL", name: "Florida" },
  { value: "IL", name: "Illinois" },
  { value: "PA", name: "Pennsylvania" },
  { value: "OH", name: "Ohio" },
  { value: "GA", name: "Georgia" },
  { value: "NC", name: "North Carolina" },
  { value: "MI", name: "Michigan" },
];

export default function NewCampaignModal({
  show,
  onClose,
  onCreate,
  isLoading,
}) {
  const [newCampaign, setNewCampaign] = useState({
    name: "",
    state: "",
    target_calls: 100,
    script: "",
  });

  const handleCreate = () => {
    onCreate(newCampaign);
  };

  const loadLifeInsuranceTemplate = () => {
    setNewCampaign({
      ...newCampaign,
      name: "Life Insurance Campaign",
      script: LIFE_INSURANCE_SCRIPT_TEMPLATE,
    });
  };

  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="w-full max-w-md bg-white rounded-xl shadow-xl border border-[#EAECF0] max-h-[90vh] overflow-y-auto">
        <div className="p-4 lg:p-6 border-b border-[#EAECF0]">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-[#101828]">
              Create New Campaign
            </h3>
            <button
              onClick={onClose}
              className="w-8 h-8 flex items-center justify-center text-[#D0D5DD] hover:text-[#667085] transition-colors"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        <div className="p-4 lg:p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-[#101828] mb-2">
              Campaign Name
            </label>
            <input
              type="text"
              value={newCampaign.name}
              onChange={(e) =>
                setNewCampaign({ ...newCampaign, name: e.target.value })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-base"
              placeholder="e.g. California Life Insurance"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-[#101828] mb-2">
              Target State (optional)
            </label>
            <select
              value={newCampaign.state}
              onChange={(e) =>
                setNewCampaign({ ...newCampaign, state: e.target.value })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-base"
            >
              <option value="">National</option>
              {states.map((state) => (
                <option key={state.value} value={state.value}>
                  {state.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-[#101828] mb-2">
              Target Calls
            </label>
            <input
              type="number"
              value={newCampaign.target_calls}
              onChange={(e) =>
                setNewCampaign({
                  ...newCampaign,
                  target_calls: parseInt(e.target.value) || 100,
                })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-base"
              min="1"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-[#101828]">
                Call Script
              </label>
              <button
                type="button"
                onClick={loadLifeInsuranceTemplate}
                className="flex items-center gap-1 text-xs text-blue-600 hover:text-blue-700 font-medium"
              >
                <FileText size={12} />
                Load Life Insurance Template
              </button>
            </div>
            <textarea
              value={newCampaign.script}
              onChange={(e) =>
                setNewCampaign({ ...newCampaign, script: e.target.value })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 h-32 resize-none text-base"
              placeholder="Hello, this is an automated call about life insurance options..."
            />
            <div className="text-xs text-gray-500 mt-1">
              💡 Use the template button above for a proven life insurance
              script
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
            <h4 className="text-sm font-semibold text-blue-900 mb-2">
              🎯 Life Insurance Funnel Tips:
            </h4>
            <ul className="text-xs text-blue-800 space-y-1">
              <li>• Lead with family protection, not sales</li>
              <li>• Offer "free consultation" not "quote"</li>
              <li>• Best times: Evenings & weekends</li>
              <li>• Target: Parents & homeowners 25-55</li>
            </ul>
          </div>
        </div>

        <div className="p-4 lg:p-6 border-t border-[#EAECF0] flex flex-col sm:flex-row gap-3">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-base"
          >
            Cancel
          </button>
          <button
            onClick={handleCreate}
            className="flex-1 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-base"
            disabled={isLoading}
          >
            {isLoading ? "Creating..." : "Create Campaign"}
          </button>
        </div>
      </div>
    </div>
  );
}
