import { useState, useEffect, useCallback } from "react";

export function useDashboard() {
  const [activeCampaigns, setActiveCampaigns] = useState([]);
  const [recentAppointments, setRecentAppointments] = useState([]);
  const [stats, setStats] = useState({
    totalCalls: 0,
    appointmentsBooked: 0,
    conversionRate: 0,
    activeCampaigns: 0,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isActionLoading, setIsActionLoading] = useState(false);
  const [lastTestCallResult, setLastTestCallResult] = useState(null);
  const [setupStatus, setSetupStatus] = useState(null);

  const fetchDashboardData = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);

      const [statsResponse, campaignsResponse, appointmentsResponse] =
        await Promise.all([
          fetch("/api/stats"),
          fetch("/api/campaigns"),
          fetch("/api/appointments?limit=5"),
        ]);

      if (!statsResponse.ok) throw new Error("Failed to fetch stats");
      if (!campaignsResponse.ok) throw new Error("Failed to fetch campaigns");
      if (!appointmentsResponse.ok)
        throw new Error("Failed to fetch appointments");

      const statsData = await statsResponse.json();
      const campaignsData = await campaignsResponse.json();
      const appointmentsData = await appointmentsResponse.json();

      setStats({
        totalCalls: statsData.overview.total_calls,
        appointmentsBooked: statsData.overview.appointments_booked,
        conversionRate: statsData.overview.conversion_rate,
        activeCampaigns: statsData.overview.active_campaigns,
      });

      setActiveCampaigns(
        campaignsData.campaigns.map((campaign) => ({
          id: campaign.id,
          name: campaign.name,
          state: campaign.state || "National",
          status: campaign.status,
          callsMade: campaign.calls_made,
          appointmentsBooked: campaign.appointments_booked,
          isRunning: campaign.status === "active",
        })),
      );

      setRecentAppointments(
        appointmentsData.appointments.map((appointment) => ({
          id: appointment.id,
          customerName: appointment.customer_name,
          phone: appointment.phone,
          scheduledFor: appointment.scheduled_for,
          agent: appointment.agent_name || "Unassigned",
          status: appointment.status,
        })),
      );
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
      setError("Failed to load dashboard data. Please try again later.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDashboardData();
  }, [fetchDashboardData]);

  const toggleCampaign = async (campaignId) => {
    try {
      const campaign = activeCampaigns.find((c) => c.id === campaignId);
      const newStatus = campaign.isRunning ? "paused" : "active";

      const response = await fetch(`/api/campaigns/${campaignId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      });

      if (!response.ok) throw new Error("Failed to update campaign");

      setActiveCampaigns((campaigns) =>
        campaigns.map((c) =>
          c.id === campaignId
            ? { ...c, isRunning: !c.isRunning, status: newStatus }
            : c,
        ),
      );

      if (newStatus === "active") {
        simulateCalls(campaignId, campaign.state);
      }
      setTimeout(() => fetchDashboardData(), 1000);
    } catch (error) {
      console.error("Error toggling campaign:", error);
      setError("Failed to update campaign status");
      fetchDashboardData();
    }
  };

  const deleteCampaign = async (campaignId) => {
    if (
      !confirm(
        "Are you sure you want to delete this campaign? This action cannot be undone.",
      )
    )
      return;

    try {
      const response = await fetch(`/api/campaigns/${campaignId}`, {
        method: "DELETE",
      });
      if (!response.ok) throw new Error("Failed to delete campaign");
      fetchDashboardData();
    } catch (error) {
      console.error("Error deleting campaign:", error);
      setError("Failed to delete campaign");
    }
  };

  const cancelAppointment = async (appointmentId) => {
    if (!confirm("Are you sure you want to cancel this appointment?")) return;

    try {
      const response = await fetch(`/api/appointments/${appointmentId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "cancelled" }),
      });
      if (!response.ok) throw new Error("Failed to cancel appointment");
      fetchDashboardData();
    } catch (error) {
      console.error("Error cancelling appointment:", error);
      setError("Failed to cancel appointment");
    }
  };

  const simulateCalls = async (campaignId, state) => {
    try {
      const numbersResponse = await fetch("/api/call-bot/generate-numbers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          state: state === "National" ? null : state,
          count: 5,
        }),
      });
      if (!numbersResponse.ok) throw new Error("Failed to generate numbers");
      const { phoneNumbers } = await numbersResponse.json();

      await fetch("/api/call-bot/simulate-call", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          campaign_id: campaignId,
          phone_numbers: phoneNumbers,
        }),
      });
    } catch (error) {
      console.error("Error simulating calls:", error);
    }
  };

  const callSpecificNumbers = async ({
    campaignId,
    phoneNumbers: phoneNumbersText,
    demoMode = false,
  }) => {
    if (!campaignId || !phoneNumbersText.trim()) {
      setError("Please select a campaign and enter phone numbers");
      return false;
    }
    setIsActionLoading(true);
    try {
      const phoneNumbers = phoneNumbersText
        .split(/\r?\n/)
        .map((num) => num.trim())
        .filter(Boolean);
      if (phoneNumbers.length === 0) {
        setError("Please enter valid phone numbers");
        return false;
      }

      const response = await fetch("/api/call-bot/simulate-call", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          campaign_id: parseInt(campaignId),
          phone_numbers: phoneNumbers,
          demo_mode: demoMode,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to call numbers");
      }

      const result = await response.json();

      if (demoMode) {
        alert(
          `Demo completed! Agent Brian simulated ${result.total_calls} calls with ${result.appointments_scheduled} appointments scheduled.`,
        );
      }

      setTimeout(() => fetchDashboardData(), 1000);
      return true;
    } catch (error) {
      console.error("Error calling specific numbers:", error);
      setError(
        demoMode
          ? "Demo failed: " + error.message
          : "Failed to call the specified numbers: " + error.message,
      );
      return false;
    } finally {
      setIsActionLoading(false);
    }
  };

  const createCampaign = async (newCampaign) => {
    if (!newCampaign.name.trim()) {
      setError("Campaign name is required");
      return false;
    }
    setIsActionLoading(true);
    try {
      const response = await fetch("/api/campaigns", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newCampaign.name,
          state: newCampaign.state || null,
          target_calls: newCampaign.target_calls,
          script: newCampaign.script,
        }),
      });
      if (!response.ok) throw new Error("Failed to create campaign");
      fetchDashboardData();
      return true;
    } catch (error) {
      console.error("Error creating campaign:", error);
      setError("Failed to create campaign");
      return false;
    } finally {
      setIsActionLoading(false);
    }
  };

  const testCallMe = async ({
    campaignId,
    phoneNumber,
    customScript,
    demoMode = false,
  }) => {
    if (!campaignId || !phoneNumber.trim()) {
      setError("Please select a campaign and enter your phone number");
      return false;
    }
    setIsActionLoading(true);
    try {
      let formattedNumber;

      if (demoMode) {
        // For demo mode, accept any phone number format
        formattedNumber = phoneNumber.trim();
      } else {
        // For real calls, format the phone number properly
        const cleaned = phoneNumber.replace(/[^\d]/g, "");
        if (cleaned.length === 10) formattedNumber = `+1${cleaned}`;
        else if (cleaned.length === 11 && cleaned.startsWith("1"))
          formattedNumber = `+${cleaned}`;
        else {
          setError("Please enter a valid US phone number");
          return false;
        }
      }

      const response = await fetch("/api/call-bot/simulate-call", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          campaign_id: parseInt(campaignId),
          phone_numbers: [formattedNumber],
          demo_mode: demoMode,
          test_call: !demoMode, // Only set test_call for real calls
          test_notes: customScript
            ? `${demoMode ? "DEMO" : "TEST"} CALL - Custom script: ${customScript}`
            : `${demoMode ? "DEMO" : "TEST"} CALL - Using campaign script`,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to initiate test call");
      }

      const result = await response.json();

      if (demoMode) {
        // For demo mode, show simulation results
        const callResult = result.call_results[0];
        let demoMessage = `Demo test completed for ${formattedNumber}!\n\n`;
        demoMessage += `Agent Brian simulated: ${callResult.status}\n`;
        if (callResult.appointmentScheduled) {
          demoMessage += `✅ Appointment scheduled with ${callResult.customerName}\n`;
        }
        demoMessage += `Call duration: ${callResult.duration} seconds\n`;
        demoMessage += `Notes: ${callResult.notes}`;

        alert(demoMessage);
      } else {
        // Store test call result for feedback (real calls only)
        setLastTestCallResult({
          campaignId: parseInt(campaignId),
          campaignName:
            activeCampaigns.find((c) => c.id === parseInt(campaignId))?.name ||
            "Unknown Campaign",
          callResult: result.call_results[0],
          phoneNumber: formattedNumber,
        });

        alert(
          `Test call initiated to ${formattedNumber}! Answer the call to test Agent Brian.`,
        );
      }

      setTimeout(() => fetchDashboardData(), 1000);
      return true;
    } catch (error) {
      console.error("Error initiating test call:", error);
      setError(
        demoMode
          ? "Demo test failed: " + error.message
          : "Failed to initiate test call: " + error.message,
      );
      return false;
    } finally {
      setIsActionLoading(false);
    }
  };

  const submitFeedback = async ({ rating, feedbackText, suggestions }) => {
    if (!lastTestCallResult) {
      setError("No test call result found");
      return false;
    }

    setIsActionLoading(true);
    try {
      const response = await fetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          campaign_id: lastTestCallResult.campaignId,
          rating,
          feedback_text: feedbackText,
          suggestions,
          feedback_type: "test_call",
        }),
      });

      if (!response.ok) throw new Error("Failed to submit feedback");

      // Clear the test call result after feedback submission
      setLastTestCallResult(null);

      return true;
    } catch (error) {
      console.error("Error submitting feedback:", error);
      setError("Failed to submit feedback");
      return false;
    } finally {
      setIsActionLoading(false);
    }
  };

  const clearLastTestCallResult = () => {
    setLastTestCallResult(null);
  };

  const checkEnvironmentSetup = async () => {
    try {
      setIsActionLoading(true);
      const response = await fetch("/api/debug/env-check");
      if (!response.ok) throw new Error("Failed to check environment setup");
      const result = await response.json();
      setSetupStatus(result);
      return result;
    } catch (error) {
      console.error("Error checking environment setup:", error);
      setError("Failed to check environment setup: " + error.message);
      return null;
    } finally {
      setIsActionLoading(false);
    }
  };

  return {
    stats,
    activeCampaigns,
    recentAppointments,
    isLoading,
    isActionLoading,
    error,
    lastTestCallResult,
    setupStatus,
    setError,
    toggleCampaign,
    deleteCampaign,
    cancelAppointment,
    createCampaign,
    callSpecificNumbers,
    testCallMe,
    submitFeedback,
    clearLastTestCallResult,
    checkEnvironmentSetup,
  };
}
