import { useState } from 'react';

export default function DebugPage() {
  const [envStatus, setEnvStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  const checkEnvironment = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/debug/env-check');
      const data = await response.json();
      setEnvStatus(data);
    } catch (error) {
      setEnvStatus({
        success: false,
        message: 'Failed to check environment',
        error: error.message
      });
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Agent Brian Debug Center</h1>
        
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Environment Check</h2>
          <p className="text-gray-600 mb-4">
            Let's check if your Twilio credentials are properly configured in your live environment.
          </p>
          
          <button
            onClick={checkEnvironment}
            disabled={loading}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md disabled:opacity-50"
          >
            {loading ? 'Checking...' : 'Check Twilio Configuration'}
          </button>
        </div>

        {envStatus && (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">Configuration Status</h3>
            
            <div className={`p-4 rounded-md mb-4 ${envStatus.success ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
              <p className={`font-medium ${envStatus.success ? 'text-green-800' : 'text-red-800'}`}>
                {envStatus.message}
              </p>
            </div>

            {envStatus.variables && (
              <div className="space-y-3">
                <h4 className="font-medium">Environment Variables:</h4>
                {Object.entries(envStatus.variables).map(([key, value]) => (
                  <div key={key} className="flex justify-between items-center p-3 bg-gray-50 rounded">
                    <span className="font-mono text-sm">{key}</span>
                    <span className={`text-sm ${value.includes('NOT SET') ? 'text-red-600' : 'text-green-600'}`}>
                      {value}
                    </span>
                  </div>
                ))}
              </div>
            )}

            {envStatus.recommendations && envStatus.recommendations.length > 0 && (
              <div className="mt-6">
                <h4 className="font-medium mb-3">Recommendations:</h4>
                <ul className="space-y-2">
                  {envStatus.recommendations.map((rec, index) => (
                    <li key={index} className="flex items-start">
                      <span className="text-blue-600 mr-2">•</span>
                      <span className="text-gray-700">{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {envStatus.success && (
              <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-md">
                <h4 className="font-medium text-blue-800 mb-2">Next Steps:</h4>
                <p className="text-blue-700">
                  Your Twilio credentials look good! If calls are still not working, the issue might be:
                </p>
                <ul className="mt-2 space-y-1 text-blue-700">
                  <li>• Twilio phone number not verified or configured</li>
                  <li>• Webhook URLs not accessible from Twilio</li>
                  <li>• Twilio account permissions or billing issues</li>
                  <li>• Target phone numbers not in the correct format</li>
                </ul>
              </div>
            )}
          </div>
        )}

        <div className="mt-6 bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
          <div className="space-y-3">
            <button
              onClick={() => window.open('https://console.twilio.com/us1/develop/phone-numbers/manage/incoming', '_blank')}
              className="w-full text-left p-3 bg-gray-50 hover:bg-gray-100 rounded border"
            >
              <div className="font-medium">Check Twilio Phone Numbers</div>
              <div className="text-sm text-gray-600">Verify your Twilio phone number is active and configured</div>
            </button>
            
            <button
              onClick={() => window.open('https://console.twilio.com/us1/monitor/logs/calls', '_blank')}
              className="w-full text-left p-3 bg-gray-50 hover:bg-gray-100 rounded border"
            >
              <div className="font-medium">View Twilio Call Logs</div>
              <div className="text-sm text-gray-600">Check recent call attempts and error messages</div>
            </button>
            
            <button
              onClick={() => window.open('https://console.twilio.com/us1/account/usage', '_blank')}
              className="w-full text-left p-3 bg-gray-50 hover:bg-gray-100 rounded border"
            >
              <div className="font-medium">Check Twilio Account Balance</div>
              <div className="text-sm text-gray-600">Make sure you have sufficient credits for calls</div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}