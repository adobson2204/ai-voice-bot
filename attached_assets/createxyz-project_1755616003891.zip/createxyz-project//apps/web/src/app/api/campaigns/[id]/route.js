import sql from "@/app/api/utils/sql";

// GET - Get single campaign with details
export async function GET(request, { params }) {
  try {
    const { id } = params;

    const [campaign] = await sql`
      SELECT 
        c.*,
        COALESCE(a.appointment_count, 0) as appointments_booked,
        COALESCE(cl.call_count, 0) as calls_made
      FROM campaigns c
      LEFT JOIN (
        SELECT campaign_id, COUNT(*) as appointment_count 
        FROM appointments 
        GROUP BY campaign_id
      ) a ON c.id = a.campaign_id
      LEFT JOIN (
        SELECT campaign_id, COUNT(*) as call_count 
        FROM call_logs 
        GROUP BY campaign_id
      ) cl ON c.id = cl.campaign_id
      WHERE c.id = ${id}
    `;

    if (!campaign) {
      return Response.json({ error: 'Campaign not found' }, { status: 404 });
    }

    return Response.json({ campaign });
  } catch (error) {
    console.error('Error fetching campaign:', error);
    return Response.json({ error: 'Failed to fetch campaign' }, { status: 500 });
  }
}

// PUT - Update campaign
export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();
    const { name, state, status, target_calls, script } = body;

    // Build dynamic update query
    const updates = [];
    const values = [];
    let paramCount = 1;

    if (name !== undefined) {
      updates.push(`name = $${paramCount}`);
      values.push(name);
      paramCount++;
    }
    if (state !== undefined) {
      updates.push(`state = $${paramCount}`);
      values.push(state);
      paramCount++;
    }
    if (status !== undefined) {
      updates.push(`status = $${paramCount}`);
      values.push(status);
      paramCount++;
    }
    if (target_calls !== undefined) {
      updates.push(`target_calls = $${paramCount}`);
      values.push(target_calls);
      paramCount++;
    }
    if (script !== undefined) {
      updates.push(`script = $${paramCount}`);
      values.push(script);
      paramCount++;
    }

    if (updates.length === 0) {
      return Response.json({ error: 'No fields to update' }, { status: 400 });
    }

    updates.push(`updated_at = CURRENT_TIMESTAMP`);
    
    // Add id to values array and set correct parameter number
    values.push(id);
    const idParam = paramCount;

    const query = `
      UPDATE campaigns 
      SET ${updates.join(', ')} 
      WHERE id = $${idParam}
      RETURNING *
    `;

    const [campaign] = await sql(query, values);

    if (!campaign) {
      return Response.json({ error: 'Campaign not found' }, { status: 404 });
    }

    return Response.json({ campaign });
  } catch (error) {
    console.error('Error updating campaign:', error);
    return Response.json({ error: 'Failed to update campaign' }, { status: 500 });
  }
}

// DELETE - Delete campaign
export async function DELETE(request, { params }) {
  try {
    const { id } = params;

    // Delete related records first
    await sql`DELETE FROM call_logs WHERE campaign_id = ${id}`;
    await sql`DELETE FROM appointments WHERE campaign_id = ${id}`;
    
    const [campaign] = await sql`
      DELETE FROM campaigns 
      WHERE id = ${id}
      RETURNING *
    `;

    if (!campaign) {
      return Response.json({ error: 'Campaign not found' }, { status: 404 });
    }

    return Response.json({ message: 'Campaign deleted successfully' });
  } catch (error) {
    console.error('Error deleting campaign:', error);
    return Response.json({ error: 'Failed to delete campaign' }, { status: 500 });
  }
}