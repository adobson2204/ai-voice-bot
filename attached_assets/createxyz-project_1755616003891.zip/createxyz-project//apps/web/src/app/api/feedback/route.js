import sql from "@/app/api/utils/sql";

// Handle feedback submission for test calls and general feedback
export async function POST(request) {
  try {
    const body = await request.json();
    const { call_log_id, campaign_id, rating, feedback_text, feedback_type = 'test_call', suggestions } = body;

    if (!campaign_id || !rating || !feedback_text) {
      return Response.json({ 
        error: 'Campaign ID, rating, and feedback text are required' 
      }, { status: 400 });
    }

    // Validate rating is between 1-5
    if (rating < 1 || rating > 5) {
      return Response.json({ 
        error: 'Rating must be between 1 and 5' 
      }, { status: 400 });
    }

    // Create feedback table if it doesn't exist
    await sql`
      CREATE TABLE IF NOT EXISTS feedback (
        id SERIAL PRIMARY KEY,
        call_log_id INTEGER,
        campaign_id INTEGER NOT NULL,
        rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
        feedback_text TEXT NOT NULL,
        feedback_type VARCHAR(50) DEFAULT 'test_call',
        suggestions TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (campaign_id) REFERENCES campaigns(id),
        FOREIGN KEY (call_log_id) REFERENCES call_logs(id)
      )
    `;

    // Insert feedback
    const [feedback] = await sql`
      INSERT INTO feedback (call_log_id, campaign_id, rating, feedback_text, feedback_type, suggestions)
      VALUES (${call_log_id || null}, ${campaign_id}, ${rating}, ${feedback_text}, ${feedback_type}, ${suggestions || null})
      RETURNING *
    `;

    return Response.json({ 
      success: true,
      feedback_id: feedback.id,
      message: 'Feedback submitted successfully'
    });
  } catch (error) {
    console.error('Error submitting feedback:', error);
    return Response.json({ error: 'Failed to submit feedback' }, { status: 500 });
  }
}

// Get feedback for a specific campaign or all feedback
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const campaign_id = searchParams.get('campaign_id');
    const limit = parseInt(searchParams.get('limit')) || 50;

    let feedbackQuery;
    if (campaign_id) {
      feedbackQuery = sql`
        SELECT f.*, c.name as campaign_name 
        FROM feedback f 
        JOIN campaigns c ON f.campaign_id = c.id 
        WHERE f.campaign_id = ${campaign_id}
        ORDER BY f.created_at DESC 
        LIMIT ${limit}
      `;
    } else {
      feedbackQuery = sql`
        SELECT f.*, c.name as campaign_name 
        FROM feedback f 
        JOIN campaigns c ON f.campaign_id = c.id 
        ORDER BY f.created_at DESC 
        LIMIT ${limit}
      `;
    }

    const feedback = await feedbackQuery;

    // Calculate summary stats
    const totalFeedback = feedback.length;
    const averageRating = totalFeedback > 0 
      ? (feedback.reduce((sum, f) => sum + f.rating, 0) / totalFeedback).toFixed(1)
      : 0;

    const ratingDistribution = {
      1: feedback.filter(f => f.rating === 1).length,
      2: feedback.filter(f => f.rating === 2).length,
      3: feedback.filter(f => f.rating === 3).length,
      4: feedback.filter(f => f.rating === 4).length,
      5: feedback.filter(f => f.rating === 5).length,
    };

    return Response.json({
      feedback,
      summary: {
        total_feedback: totalFeedback,
        average_rating: parseFloat(averageRating),
        rating_distribution: ratingDistribution
      }
    });
  } catch (error) {
    console.error('Error fetching feedback:', error);
    return Response.json({ error: 'Failed to fetch feedback' }, { status: 500 });
  }
}