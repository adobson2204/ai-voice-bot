import { RefreshControl } from 'react-native-web-refresh-control';

export default RefreshControl;
